# Read Me First
This project houses a Spring-boot rest API with the end-point : "/transactions" in the controller - RewardsController.

It takes a request body data which can be modeled as below : 
Sample JSON body :

{
  	"transactionDetails":[
    	{
    		"merchantName":"RILEYS",
    		"amount":130,
    		"transactionDate":"2019-04-28T14:45:15"
    	}
    ,
    	{
    		"merchantName":"WENDYs",
    		"amount":50,
    		"transactionDate":"2019-04-28T14:45:15"
    	}
    ]
}

Response codes: 
200- OK for success giving away the total points for the user's total spend.(Given that the sent transactions are for a desired time-period.)
503 - Exception in the functionality
500 - Internal server error

Sample response : 

{
    "totalPoints": 110,
    "statusCode": "OK"
}


