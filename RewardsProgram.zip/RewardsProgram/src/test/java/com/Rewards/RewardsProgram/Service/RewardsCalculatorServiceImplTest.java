package com.Rewards.RewardsProgram.Service;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import com.Rewards.RewardsProgram.DTO.RewardPoints;
import com.Rewards.RewardsProgram.DTO.TransactionDetail;


@RunWith(MockitoJUnitRunner.class)
class RewardsCalculatorServiceImplTest {
	
@InjectMocks
	RewardsCalculatorServiceImpl rewardsCalculatorService;
@Mock
	RewardPoints rewardPoints;
@Mock
TransactionDetail transactionDetails;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		transactionDetails = new TransactionDetail("Sri",120.00, new Date());
	}


/**
This is the unit test method to verify the calculation logic for transactions above $100
*/
	@Test
	void testGetTotalPointsForSpendAbove100() {

		rewardPoints = rewardsCalculatorService.getTotalPoints(transactionDetails);
		assertThat(rewardPoints.getTotalPoints()).isGreaterThan(0);
	}

/**
This is the unit test method to verify the calculation logic for transactions below $50
*/
	@Test
	void testGetTotalPointsForSpendBelow50() {
		transactionDetails = new TransactionDetail("Sriram",49.00, new Date());
		transactionDetails.setAmount(49);
		rewardPoints = rewardsCalculatorService.getTotalPoints(transactionDetails);
		assertThat(rewardPoints.getTotalPoints()).isEqualTo(0);
	}
}
