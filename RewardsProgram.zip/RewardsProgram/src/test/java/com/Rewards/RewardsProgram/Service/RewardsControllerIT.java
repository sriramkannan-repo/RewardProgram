package com.Rewards.RewardsProgram.Service;

import java.util.ArrayList;
import java.util.Date;

import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.skyscreamer.jsonassert.JSONAssert;

import com.Rewards.RewardsProgram.RewardsProgramApplication;
import com.Rewards.RewardsProgram.DTO.*;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(classes = RewardsProgramApplication.class, webEnvironment =WebEnvironment.DEFINED_PORT)
public class RewardsControllerIT {
	 TestRestTemplate restTemplate = new TestRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		@LocalServerPort
	    private int port= 8080;
	@Test
	public void testcalculateRewardPoints() throws JSONException {
		
		TransactionDetail detail = new TransactionDetail("Greg", 50.00, new Date());
		ArrayList<TransactionDetail> listDetails = new ArrayList<>();
		listDetails.add(detail);
		Transaction transaction = new Transaction(listDetails);
		HttpEntity<Transaction> entity = new HttpEntity<Transaction>(transaction);
		ResponseEntity<String> response = restTemplate.exchange(
				createURLWithPort("/transactions"),
				HttpMethod.POST, entity, String.class);
		String expected = "{\"totalPoints\":6}";
		 JSONAssert.assertEquals(expected, response.getBody().toString(), false);
	}
	private String createURLWithPort(String uri) {
        return "http://localhost:" + port + uri;
    }

}
