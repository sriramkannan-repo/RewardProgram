package com.Rewards.RewardsProgram.Service;
import com.Rewards.RewardsProgram.DTO.TransactionDetail;
import org.springframework.stereotype.Component;
import com.Rewards.RewardsProgram.DTO.RewardPoints;

@Component
public interface RewardsCalculatorService {
	
	public RewardPoints getTotalPoints(TransactionDetail transactionDetails) ;
	
}
