package com.Rewards.RewardsProgram.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.Rewards.RewardsProgram.DTO.RewardPoints;
import com.Rewards.RewardsProgram.DTO.Transaction;
import com.Rewards.RewardsProgram.DTO.TransactionDetail;
import com.Rewards.RewardsProgram.Service.RewardsCalculatorServiceImpl;

/**
This is the controller class for the rewards Calculator
@param takes a request body JSON of the type Transaction
@return ResponseEntity<RewardPoints>
*/
@RestController
public class RewardsController {
	@Autowired
	public RewardsCalculatorServiceImpl rewardService;
	
	@PostMapping(value = "/transactions", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<RewardPoints> calculateRewardPoints(@RequestBody Transaction transactions) {
		RewardPoints rewardPoints = new RewardPoints();
		int rewardPointsTotal =0;
		try {
				if( null!=transactions ) 
				{
					for (TransactionDetail transactionDetail : transactions.getTransactionDetails()) 
					{
						rewardPoints = rewardService.getTotalPoints(transactionDetail);
						rewardPointsTotal = rewardPointsTotal + rewardPoints.getTotalPoints();
					}
					rewardPoints.setTotalPoints(rewardPointsTotal);
					rewardPoints.setStatusCode(HttpStatus.OK);
				}
			}
		
		catch (Exception e) 
		{
			rewardPoints.setStatusCode(HttpStatus.EXPECTATION_FAILED);
			return new ResponseEntity<RewardPoints>(rewardPoints,HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<RewardPoints>(rewardPoints,HttpStatus.OK);
	}
}
