package com.Rewards.RewardsProgram.DTO;

import java.io.Serializable;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
@JsonDeserialize
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	public ArrayList<TransactionDetail> transactionDetails;
	public ArrayList<TransactionDetail> getTransactionDetails() {
		return transactionDetails;
	}
	public void setTransactionDetails(ArrayList<TransactionDetail> transactionDetails) {
		this.transactionDetails = transactionDetails;
	}
	public Transaction(@JsonProperty("transactionDetails") ArrayList<TransactionDetail> transactionDetails) {
		
		this.transactionDetails = transactionDetails;
	}
	
	




	
	
}
