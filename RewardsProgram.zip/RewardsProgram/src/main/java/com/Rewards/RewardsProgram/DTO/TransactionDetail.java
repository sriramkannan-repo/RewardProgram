package com.Rewards.RewardsProgram.DTO;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;


@JsonDeserialize
public class TransactionDetail implements Serializable {
	private static final long serialVersionUID = 1L;

public String merchantName;
public double amount;
public Date transactionDate;

public Date getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(Date transactionDate) {
	this.transactionDate = transactionDate;
}
public String getMerchantName() {
	return merchantName;
}
public void setMerchantName(String merchantName) {
	this.merchantName = merchantName;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public TransactionDetail(@JsonProperty("merchantName") String merchantName, @JsonProperty("amount") double amount, @JsonProperty("transactionDate") Date transactionDate) {
	
	this.merchantName = merchantName;
	this.amount = amount;
	this.transactionDate = transactionDate;
}

}
