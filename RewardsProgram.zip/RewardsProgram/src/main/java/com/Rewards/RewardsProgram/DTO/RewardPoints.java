package com.Rewards.RewardsProgram.DTO;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class RewardPoints {

	public Integer totalPoints;
	public HttpStatus statusCode;

	public Integer getTotalPoints() {
		return totalPoints;
	}

	public void setTotalPoints(Integer totalPoints) {
		this.totalPoints = totalPoints;
	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}
	
	
	
}
