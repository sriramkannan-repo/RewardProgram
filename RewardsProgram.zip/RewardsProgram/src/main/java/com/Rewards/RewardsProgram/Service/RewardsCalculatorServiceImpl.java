package com.Rewards.RewardsProgram.Service;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.Rewards.RewardsProgram.DTO.RewardPoints;
import com.Rewards.RewardsProgram.DTO.TransactionDetail;
@Component
public class RewardsCalculatorServiceImpl implements RewardsCalculatorService{

	
/**
This is the service method that contains logic to calculate points based on 
each transaction of the customer called over in loop.
@param TransactionDetail
@return RewardPoints
*/
	public RewardPoints getTotalPoints(TransactionDetail transactionDetail) {

		RewardPoints rewardPoints = new RewardPoints();
		try {
			Integer lowerTransaction = 50;
			Integer upperTransactionValue = 100;
			if(Optional.of(transactionDetail)!=null) {
				if(Optional.of(transactionDetail.getAmount()).isPresent()) 
				{
					if(transactionDetail.getAmount()>upperTransactionValue) {
						Integer transactionAmount = (int)transactionDetail.getAmount();
						Integer parTransactionAmount = transactionAmount-upperTransactionValue;
						Integer totalRewardpoints = parTransactionAmount*2 + lowerTransaction;
						rewardPoints.setTotalPoints(totalRewardpoints);
					}
					else if(transactionDetail.getAmount()<=upperTransactionValue && transactionDetail.getAmount()>lowerTransaction) 
					{
						Integer rewardAboveMinthreshold = (int)transactionDetail.getAmount()-lowerTransaction;
						rewardPoints.setTotalPoints(rewardAboveMinthreshold);
					}
					else 
					{
						rewardPoints.setTotalPoints(0);
					}
				}
			}
		}catch (Exception e) {
			throw e;
		}
		return  rewardPoints;
	}

	

	
}
